# Student 5 – Personalization Forms, Contacts & Notification Bridges

**Role:** Personalization Forms, Contacts & Notification Bridges

## Front-end responsibilities
- Contact page with validated inquiry form and categories — `routes/contact.tsx`
- Custom chocolate sampler builder — `routes/sampler.tsx`
- WhatsApp redirection links and floating action button — `WhatsAppFab.tsx`, `lib/site.ts`

## Back-end responsibilities (to build)
- Strict validation models (Joi / Zod) for inquiry entries
- Nodemailer SMTP bridge routing wholesale and support inquiries to SolCacao teams (HTML email templates)
- `POST /api/contact` and `POST /api/sampler-requests`

## Files owned (under `app/`)
- `app/src/routes/contact.tsx`
- `app/src/routes/sampler.tsx`
- `app/src/components/site/WhatsAppFab.tsx`
- `app/src/lib/site.ts`
- `app/src/assets/p-truffles.jpg` (copy; original owned by Student 3)

## Depends on (owned by others)
- Student 2: `useI18n`, `PageHeader`, shared UI kit
- Student 3: `useCart`, `PRODUCTS`, `formatPrice` (sampler adds a box to the cart)
