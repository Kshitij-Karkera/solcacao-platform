/** Placeholder contact details — replace with real SolCacao info. */
export const WHATSAPP_NUMBER = "5215500000000";
export const CONTACT_EMAIL = "hola@solcacao.example";
export const ATELIER_ADDRESS = "Calle del Cacao 12, Oaxaca, México";

export function whatsappLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
