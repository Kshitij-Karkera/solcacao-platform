import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Clock, Mail, MapPin, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/site/PageHeader";
import { useI18n } from "@/lib/i18n";
import { ATELIER_ADDRESS, CONTACT_EMAIL, whatsappLink } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact SolCacao — Orders, Wholesale & Samples" },
      {
        name: "description",
        content: "Reach the SolCacao team about retail orders, wholesale, B2B samples or support.",
      },
      { property: "og:title", content: "Contact SolCacao" },
      { property: "og:description", content: "Email or WhatsApp our chocolate team." },
    ],
  }),
  component: Contact,
});

type Topic = "retail" | "wholesale" | "sample" | "support";

function Contact() {
  const { t, lang } = useI18n();
  const c = t.contact;
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [topic, setTopic] = useState<Topic>("retail");
  const [errors, setErrors] = useState<Partial<Record<"name" | "email" | "message", string>>>({});

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const schema = z.object({
      name: z.string().trim().min(1, c.errors.name).max(100),
      email: z.string().trim().email(c.errors.email).max(255),
      message: z.string().trim().min(10, c.errors.message).max(2000),
    });
    const r = schema.safeParse(form);
    if (!r.success) {
      const errs: Partial<Record<"name" | "email" | "message", string>> = {};
      r.error.issues.forEach((i) => (errs[i.path[0] as "name" | "email" | "message"] = i.message));
      setErrors(errs);
      return;
    }
    setErrors({});
    setForm({ name: "", email: "", message: "" });
    toast.success(c.sent);
  };

  const waMessage =
    lang === "es"
      ? `¡Hola SolCacao! Tengo una consulta sobre: ${c.categories[topic]}`
      : `Hi SolCacao! I have a question about: ${c.categories[topic]}`;

  return (
    <>
      <PageHeader eyebrow={c.eyebrow} title={c.title} body={c.body} />
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[1fr_380px]">
        <form
          onSubmit={submit}
          className="space-y-5 rounded-2xl border border-border bg-card p-6 md:p-10"
          noValidate
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="c-name">{c.name}</Label>
              <Input
                id="c-name"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                className="h-11 bg-background"
              />
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="c-email">{c.email}</Label>
              <Input
                id="c-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                className="h-11 bg-background"
              />
              {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="c-topic">{c.category}</Label>
            <Select value={topic} onValueChange={(v) => setTopic(v as Topic)}>
              <SelectTrigger id="c-topic" className="h-11 bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(c.categories) as Topic[]).map((k) => (
                  <SelectItem key={k} value={k}>
                    {c.categories[k]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="c-message">{c.message}</Label>
            <Textarea
              id="c-message"
              rows={6}
              value={form.message}
              onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
              className="bg-background"
            />
            {errors.message && <p className="text-xs text-destructive">{errors.message}</p>}
          </div>
          <Button type="submit" size="lg">
            {c.send}
          </Button>
        </form>

        <aside className="space-y-6">
          <div className="rounded-2xl bg-cocoa p-8 text-cocoa-foreground">
            <MessageCircle className="h-6 w-6 text-gold" />
            <p className="mt-4 font-display text-2xl">{c.whatsapp}</p>
            <p className="mt-2 text-sm text-cocoa-foreground/75">{c.whatsappBody}</p>
            <Button variant="whatsapp" className="mt-6 w-full" asChild>
              <a href={whatsappLink(waMessage)} target="_blank" rel="noreferrer">
                {c.whatsapp}
              </a>
            </Button>
          </div>
          <div className="space-y-4 rounded-2xl border border-border p-8">
            <p className="font-display text-xl">{c.visit}</p>
            <p className="flex items-start gap-3 text-sm text-muted-foreground">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0" /> {ATELIER_ADDRESS}
            </p>
            <p className="flex items-center gap-3 text-sm text-muted-foreground">
              <Mail className="h-4 w-4" /> {CONTACT_EMAIL}
            </p>
            <p className="flex items-center gap-3 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" /> {c.hours}
            </p>
          </div>
        </aside>
      </div>
    </>
  );
}
