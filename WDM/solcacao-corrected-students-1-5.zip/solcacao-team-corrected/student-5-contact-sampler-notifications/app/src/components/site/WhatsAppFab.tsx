import { MessageCircle } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { whatsappLink } from "@/lib/site";

/** Floating automated WhatsApp redirection link. */
export function WhatsAppFab() {
  const { t, lang } = useI18n();
  const msg =
    lang === "es" ? "¡Hola SolCacao! Tengo una pregunta." : "Hi SolCacao! I have a question.";
  return (
    <aside aria-label={t.contact.whatsapp}>
      <a
        href={whatsappLink(msg)}
        target="_blank"
        rel="noreferrer"
        aria-label={t.contact.whatsapp}
        className="fixed bottom-5 right-5 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-whatsapp-foreground shadow-lift transition-transform hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
      >
        <MessageCircle aria-hidden="true" className="h-6 w-6" />
      </a>
    </aside>
  );
}
