# Student 4 – B2B Services & Step-by-Step Customization Wizard

**Role:** B2B Services & Customization Wizard (plus landing page)

## Front-end responsibilities
- Landing homepage: hero slides, seasonal cacao showcase, retail/B2B channel cards — `routes/index.tsx`
- B2B Wholesale page showcasing custom confectionery services — `routes/wholesale.tsx`
- Interactive 4-step custom-order wizard with completed-step states — `QuoteWizard.tsx`

## Back-end responsibilities (to build)
- `B2BCustomRequest` collection model
- `POST /api/b2b/requests` handling multipart form-data (metadata + technical design/logo uploads, via `multer`)
- File storage logic for corporate mold files (local disk or AWS S3)

## Files owned (under `app/`)
- `app/src/routes/index.tsx`
- `app/src/routes/wholesale.tsx`
- `app/src/components/site/QuoteWizard.tsx`
- `app/src/assets/hero-cacao.jpg`, `hero-truffles.jpg`, `b2b-custom.jpg`
- `app/src/assets/p-bonbons.jpg` (copy; original owned by Student 3)

## Depends on (owned by others)
- Student 2: `useI18n`, shared UI kit
- Student 3: `ProductCard`, `PRODUCTS`/`ORIGINS`, `formatPrice`
- Student 1: `useAuth` (wizard pre-fills partner details)
