# SolCacao corrected frontend

This directory is the combined app for Students 1–5. The separate student archive retains the original ownership structure. New shared storage utilities and regression tests belong to Student 2; tests exercise all five subsystems.

## Run

Use Node.js 22.12 or newer (tested with Node 24 on Windows).

```powershell
npm ci
npm run dev -- --host 127.0.0.1 --port 5174
```

Open http://127.0.0.1:5174. The app uses browser-local mock data. Demo sign-in does not verify credentials. Do not use a real password. Contact, newsletter, quote upload and checkout do not contact a backend or payment provider. WhatsApp destinations are placeholders.

## Automated checks

```powershell
npm test
npx tsc --noEmit
npm run lint
npm run build
```

Expected: 18 tests pass, TypeScript passes, lint exits successfully with 13 fast-refresh warnings, production build passes. Warnings do not indicate a failed check. The deployment preset remains the supplied Cloudflare preset; UTA hosting has not been configured or deployed.

## Browser journeys

Keep the dev server running on port 5174. The browser script uses a fresh isolated profile and demo data. It never submits messages to real recipients or opens WhatsApp.

```powershell
npm install --no-save --package-lock=false playwright
node tests/browser-test.cjs
```

Microsoft Edge must be installed. To select installed Chrome, set `$env:BROWSER_CHANNEL = 'chrome'`. Set `$env:BASE_URL` to test another locally running instance. Results and screenshots are written under `test-results/`, or `$env:TEST_OUTPUT_DIR` if set. Only Edge was exercised for the supplied results.

The checks cover desktop (1440 × 1000) and mobile (390 × 844) routes, navigation, localization persistence, catalog search/sorting, product cart, registration, quote wizard, contact validation, sampler localization, browser storage recovery and uncaught browser exceptions. This is representative frontend coverage, not an exhaustive accessibility, security or cross-browser audit.

## Student-folder assembly on Windows

From the extracted team directory:

```powershell
New-Item -ItemType Directory -Force combined | Out-Null
Get-ChildItem -Directory student-* | ForEach-Object {
  Get-ChildItem ($_.FullName + '/app') -Force | Copy-Item -Destination combined -Recurse -Force
}
Set-Location combined
npm ci
npm run dev -- --host 127.0.0.1 --port 5174
```

Use the combined-app ZIP if you want to run it without assembling student folders.
