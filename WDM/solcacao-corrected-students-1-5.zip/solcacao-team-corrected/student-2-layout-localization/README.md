# Student 2 – Core Layout, Navigation & Localization

**Role:** Core Layout, Navigation & Localization (plus project foundation)

## Front-end responsibilities
- App shell: root layout, providers, skip link, landmarks — `routes/__root.tsx`
- Sticky navbar with search trigger, cart count, responsive slide-out mobile menu — `SiteHeader.tsx`
- Global footer, logo, shared page header — `SiteFooter.tsx`, `Logo.tsx`, `PageHeader.tsx`
- Client-side routing setup — `router.tsx`, `routeTree.gen.ts`, `start.ts`, `server.ts`
- Global EN/ES localization toggle and dictionaries — `LanguageToggle.tsx`, `lib/i18n.tsx`
- Design tokens / global styles — `styles.css`

## Back-end responsibilities (to build)
- API routes serving server-side localization dictionaries (`GET /api/i18n/:lang`) to replace the bundled dictionaries in `lib/i18n.tsx`
- Static file / asset routing configuration on the server
- Error-capture and error-page plumbing

## Files owned (under `app/`)
- Source: `app/src/routes/__root.tsx`, `router.tsx`, `routeTree.gen.ts`, `start.ts`, `server.ts`, `styles.css`
- Components: `SiteHeader`, `SiteFooter`, `LanguageToggle`, `Logo`, `PageHeader`
- Libs/hooks: `lib/i18n.tsx`, `lib/utils.ts`, `lib/error-*.ts`, `lib/lovable-error-reporting.ts`, `hooks/use-mobile.tsx`
- Shared UI kit: `src/components/ui/*` (shadcn)
- Tests: `src/test/*`
- Project config & docs: `package.json`, `bun.lock`, `vite.config.ts`, `vitest.config.ts`, `tsconfig.json`, `eslint.config.js`, `components.json`, `.prettierrc`, `.gitignore`, `public/*`, `README.md`, `AGENTS.md`, `roadmap.md`

## Depends on (owned by others)
- Student 1 / 3 (providers mounted in the root: `AuthProvider`, `CartProvider`, `CartDrawer`, `AuthDialog`)
- Student 5 (`WhatsAppFab` mounted in the root)
