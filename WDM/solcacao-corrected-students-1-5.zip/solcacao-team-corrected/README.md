# SolCacao – Team Repository

Prototype of the SolCacao chocolate storefront (React + TanStack Start + Tailwind, bilingual EN/ES).
The work is split into **five student folders**. Each folder contains only the files that student owns,
under `app/`, using the same paths as the original project — so the five `app/` folders overlay
onto one complete, runnable project.

| Folder | Student | Subsystem |
|---|---|---|
| `student-1-auth-security/` | Student 1 | Authentication, Security & Databases |
| `student-2-layout-localization/` | Student 2 | Core Layout, Navigation & Localization (also owns project config + shared UI kit) |
| `student-3-catalog-cart/` | Student 3 | Gourmet Catalog, Search & Cart State |
| `student-4-home-b2b-wizard/` | Student 4 | Home, B2B Services & Customization Wizard |
| `student-5-contact-sampler-notifications/` | Student 5 | Contact, Sampler Builder & Notification Bridges |

Each folder has its own `README.md` listing the files owned, the front-end work already present, and the
back-end deliverables still to build (the prototype is front-end only; data lives in `src/lib/*` + localStorage).

## Run the full prototype

```sh
mkdir solcacao && cp -a student-*/app/. solcacao/
cd solcacao && npm i && npm run dev
```

## Shared-file notes
- `src/lib/i18n.tsx` is a single dictionary file owned by Student 2. Each student edits only their own
  section (`auth`/`account` → S1, `nav`/`footer`/`common` → S2, `catalog`/`product`/`cart` → S3,
  `home`/`wholesale` → S4, `sampler`/`contact` → S5) and keeps EN and ES in sync.
- `src/assets/p-bonbons.jpg` (home page) and `src/assets/p-truffles.jpg` (sampler) are also used outside Student 3's
  catalog, so Students 4 and 5 hold a copy. The originals belong to Student 3.
- `package.json`, `src/components/ui/*` (shadcn kit), `src/styles.css` and tooling configs belong to Student 2.
  Anyone needing a new dependency or UI primitive requests it via a pull request touching Student 2's folder.
