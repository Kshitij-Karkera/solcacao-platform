# Student 3 – Gourmet Catalog, Search & Cart State

**Role:** Gourmet Catalog, Search & Cart State

## Front-end responsibilities
- Catalog page: responsive product grid, multi-dimensional filter sidebar (origin, cacao %, category), sorting — `routes/catalog.tsx`
- Product detail page — `routes/products.$productId.tsx`
- Product card — `ProductCard.tsx`
- Slide-out cart drawer — `CartDrawer.tsx`
- Cart state + localStorage persistence — `lib/cart.tsx`
- Product data, types, price formatting — `lib/products.ts` (+ unit test)

## Back-end responsibilities (to build)
- Schemas: `Product`, `Inventory`, `Cart`
- `GET /api/products` with server-side filters (`cacaoPct`, `origin`, `search`), pagination and sorting
- `GET /api/products/:id`
- Active-cart persistence endpoints and guest-session cart merging on login

## Files owned (under `app/`)
- `app/src/routes/catalog.tsx`
- `app/src/routes/products.$productId.tsx`
- `app/src/components/site/ProductCard.tsx`
- `app/src/components/site/CartDrawer.tsx`
- `app/src/lib/cart.tsx`
- `app/src/lib/products.ts`, `products.test.ts`
- `app/src/assets/p-*.jpg` (6 product photos)

## Depends on (owned by others)
- Student 2: `useI18n`, `PageHeader`, shared UI kit
- Student 1: `useAuth` (cart drawer prompts guests to sign in)
