# Student 1 – Authentication, Security & Databases

**Role:** Authentication, Security & Databases

## Front-end responsibilities
- Auth modal (sign in / register) with distinct flows for retail consumers vs. corporate (B2B) brands — `AuthDialog.tsx`
- Profile / account management panel — `routes/account.tsx`
- Client auth state (mock, localStorage) exposed through `useAuth()` — `lib/auth.tsx`

## Back-end responsibilities (to build)
- Mongoose schemas: `User` (Retail / B2B), `CorporatePartner`, `Address`
- Middleware: bcrypt password hashing, JWT generation + verification (Bearer header, expiry handling, user payload on `req`)
- Strict role-based route guards (retail vs. B2B vs. admin)
- Endpoints: `POST /api/auth/register`, `POST /api/auth/login`, `GET/PUT /api/users/me`; swap `lib/auth.tsx` mock for these calls

## Files owned (under `app/`)
- `app/src/components/site/AuthDialog.tsx`
- `app/src/lib/auth.tsx`
- `app/src/routes/account.tsx`

## Depends on (owned by others)
- Student 2: `useI18n`, `PageHeader`, shared UI kit
- Student 3: `useCart` (`AuthDialog` shows a "cart synced" message on sign-in)
